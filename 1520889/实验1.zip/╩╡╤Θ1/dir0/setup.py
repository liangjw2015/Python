# file setup.py
from setuptools import setup
setup(
    name='myapp',
    version='1.0',
    packages=['dir1']
    )
